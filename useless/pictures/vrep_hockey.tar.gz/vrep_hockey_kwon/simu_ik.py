import numpy as np
import pickle as pkl
import sys
from time import sleep

import rospy
from std_msgs.msg import Int32
from std_msgs.msg import Int32MultiArray
from std_msgs.msg import Float32
from std_msgs.msg import Float32MultiArray
from std_msgs.msg import Bool

class BaxterHockey:
  def __init__(self):
    self.start_sim_pub = rospy.Publisher('startSimulation', Bool, queue_size=10)
    self.stop_sim_pub = rospy.Publisher('stopSimulation', Bool, queue_size=10)
    self.ik_target_pub = rospy.Publisher('IKTarget', Float32MultiArray, queue_size=10)
    self.game_point_pub = rospy.Publisher('point', Int32MultiArray, queue_size=10)
    self.init_rate = rospy.Rate(100)
    self.simulation_state_pub = rospy.Subscriber('simulationState', Int32, self.__simulation_state_callback)
    self.puck_state_sub = rospy.Subscriber('puck_state', Float32MultiArray, self.__puck_state_callback)
    self.point = [0, 0]
    self.state_frag = False
    self.puck_state = np.zeros(4)

  def start_sim(self):
    self.sim_state = True
    frag = Bool()
    frag.data = True
    for _ in range(100):
      self.init_rate.sleep()
      self.start_sim_pub.publish(frag)

  def stop_sim(self):
    print 'stop simulation'
    frag = Bool(); frag.data = True
    self.stop_sim_pub.publish(frag)

  def __puck_state_callback(self, msg):
    self.puck_state = np.array(msg.data)

    ik = Float32MultiArray()
    ik.data = [0, 0.35]
    if self.puck_state[3]>0.01:
      predict_x = self.__predict_x(0.3)
      if self.puck_state[1]>0.2:
        y = 0.3
      else:
        y = 0.35

      ik.data = [predict_x, y]
    
    if np.linalg.norm(self.puck_state[2:]) < 0.05 and self.puck_state[1] > 0.2:
      ik.data = self.puck_state[:2]

    self.ik_target_pub.publish(ik)

    if abs(self.puck_state[1])>0.475 and not self.state_frag:
      self.point[self.puck_state[1]>0] += 1
    point = Int32MultiArray()
    point.data = self.point
    self.game_point_pub.publish(point)

    # sim end condition
    self.state_frag =  abs(self.puck_state[1])>0.475 or abs(self.puck_state[0])>0.3
    if self.state_frag or (np.linalg.norm(self.puck_state[2:])<0.001 and self.puck_state[1]>-0.1 and self.puck_state[1]<0.2):
      self.stop_sim()
  
  def __predict_x(self, y_posi):
    x, y, x_dot, y_dot = self.puck_state
    a = y_dot / x_dot
    b = y - a * x

    if a == 0:
      predict = 0
    else:
      predict = (y_posi - b) / a

      while predict < -0.205 or predict > 0.205:
        if predict < -0.205: predict = -0.41 - predict
        if predict >  0.205: predict =  0.41 - predict

    return predict

  def __simulation_state_callback(self, msg):
    state = msg.data
    if state == 0: self.start_sim()

class Director:
  def __init__(self):
    rospy.init_node('baxter_hockey', disable_signals=True)
    self.agent = BaxterHockey()
    rospy.on_shutdown(self.__shutdown)
    self.rate = rospy.Rate(1000)

    self.game_time_pub = rospy.Publisher('GameTime', Int32, queue_size=10)
    self.GameTime = 180

  def take_episode(self):
    if self.agent.puck_state[1]<0.15 and self.agent.puck_state[1]>-0.2 and self.agent.puck_state[3]>0:
      x, y, x_dot, y_dot = self.agent.puck_state
      if not y_dot == 0:
        wait_time = (0.25 - y) / y_dot
        if wait_time > 0.45:
          sleep((wait_time - 0.45))

      sleep(0.3)

    if self.agent.puck_state[1]<0.45 and self.agent.puck_state[1]>0.15 and abs(self.agent.puck_state[3])<0.1:
      x, y, x_dot, y_dot = self.agent.puck_state
      theta = np.arctan2(y-0.35, x)
      if theta < 0:
        action = int(theta * (-5) / np.pi)
        sleep(0.3)

  def episode(self):
    # while not rospy.is_shutdown():
    #   self.take_episode()
    #   self.rate.sleep()
    for i in range(self.GameTime):
      time = Int32()
      time.data = self.GameTime - i
      self.game_time_pub.publish(time)
      sleep(1)
    time = Int32()
    time.data = 0
    self.game_time_pub.publish(time)
    raise()
    # rospy.spin()

  def __shutdown(self):
    print 'ros shutdown'
    self.agent.stop_sim()



if __name__=='__main__':
  d = Director()
  d.episode()

