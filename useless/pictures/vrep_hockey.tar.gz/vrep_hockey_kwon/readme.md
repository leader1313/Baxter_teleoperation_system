# V-REPホッケーシミュレータの使い方

## Setup
- V-REP version 3.4.0
- python 2.7系
- ROS (Ubuntuのバージョンに合わせて)

## V-REPのROSセットアップ
V_REPのディレクトリ内のテキストファイル
/programming/ros_packages/ros_vrep_rosinterface_install_guide.txt
を参考にvrep_ros_interfaceのビルドを行ってください．

ビルドが完了したら，
catkin_ws/devel/lib/libv_repExtRosInterface.so
ファイルをV_REPのフォルダのトップにコピーしてください．

roscoreを起動後にV_REPを起動してください．

RosInterfaceのpluginがロードされてる，または$ rosnode listを実行して/vrep_ros_interfaceが表示されていれば設定完了です．

## 使い方
- roscoreの起動
- V-REPの起動
- sim_ik.pyの実行

- V-REP内でパックを打ち込むとBaxterが打ち返してくれます．
- pythonスクリプトをCtrl+Cで終了するとシミュレーションが終わります．
